document.addEventListener("DOMContentLoaded", function(event){
	localStorage.setItem("firstvisit2", "false");
	var categoriesButton = document.getElementById("submit_cat").addEventListener('click', budgetInfo);
});

function budgetInfo(){

	var generalBudget = document.getElementById('box1').value;
	var clothingBudget = document.getElementById('box2').value; 	
	var foodBudget = document.getElementById('box3').value;
	localStorage.setItem("totalGeneralBudget", generalBudget);
	localStorage.setItem("totalClothingBudget", clothingBudget);
	localStorage.setItem("totalFoodBudget", foodBudget);

	localStorage.setItem("alreadySpentClothing", 0);
	localStorage.setItem("alreadySpentFood", 0);
	localStorage.setItem("alreadySpentGeneral", 0);

	/*console.log(localStorage.getItem("totalClothingBudget"));
	console.log(localStorage.getItem("totalFoodBudget"));
	console.log(localStorage.getItem("totalGeneralBudget"));*/

	localStorage.setItem("firstvisit", "true");
	window.open("landing.html", "_self");
}