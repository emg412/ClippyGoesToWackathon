document.addEventListener("DOMContentLoaded", function(event){
	var popupButton = document.getElementById("enter").addEventListener('click', popupInfo);
	localStorage.setItem("firstvisit", "true");
});

function popupInfo(){

	window.open("home.html", "_self");
}