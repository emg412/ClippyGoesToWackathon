document.addEventListener("DOMContentLoaded", function(event) {
    var homeButton = document.getElementById("home");
    homeButton.onclick = home;

    var signUpButton = document.getElementById("signup");
    signUpButton.onclick = signUp;

    var aboutButton = document.getElementById("about");
    aboutButton.onclick = about;

    var name = document.getElementById("firstname");
    name.innerText = localStorage.getItem("first");

    /*var open = document.getElementById("opener");

    var cashGen = document.getElementById("cash_good");
    cashGen.style.color = "#D85637";
    cashGen.innerText = "$___.__";
    var progTopGen = document.getElementById("progressTop");
    progTopGen.style.width = "160px";
    progTopGen.style.backgroundColor = "#D85637";
    open.innerText = "Sign up to begin."

    var foodGen = document.getElementById("cash_low");
    foodGen.style.color = "#D85637";
    foodGen.innerText = "$___.__";
    var progTopFood = document.getElementById("progressBottom");
    progTopFood.style.width = "50px";
    progTopFood.style.backgroundColor = "#D85637";
    open.innerText = "Sign up to begin."*/

    getResults();
    showCart();
    showGeneral();
});

function getResults(){
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "checkForWord" }, function (response) {
            //showResults(response);
        });
        chrome.tabs.sendMessage(tabs[0].id, { action: "checkForCart" }, function (response) {
            //showCart();
        });
    });
}

/*function showResults(results) {
    var resultsElement = document.getElementById("results");
    var cashCart = document.getElementById("cashcart")
    resultsElement.innerText = (results.length > 0) ? "This is a checkout cart." : "This is NOT a checkout cart.";
}*/

function showGeneral() {
    var generalBal = localStorage.getItem("totalGeneralBudget");
    var goodcashElement = document.getElementById("cash_good");
    var progTopElement = document.getElementById("progressTop");
    var lowcashElement = document.getElementById("cash_low");
    var progBottomElement = document.getElementById("progressBottom");
    var opener = document.getElementById("opener");
    var percent = generalBal / 500;

    if (generalBal.length < 4) {
        generalBal = generalBal + ".00"
    }
    progTopElement.style.width = (160 * percent) + "px";
    if (generalBal == ".00") {
        goodcashElement.style.color = "#D85637";
        goodcashElement.innerText = "$___.__";
        progTopElement.style.width = "160px";
        progTopElement.style.backgroundColor = "#D85637";
        lowcashElement.style.color = "#D85637";
        lowcashElement.innerText = "$___.__";
        progBottomElement.style.width = "160px";
        progBottomElement.style.backgroundColor = "#D85637";
        opener.innerText = "Sign up to begin."
    }
    else {
        goodcashElement.innerText = "$" + generalBal;
    }
}

function showCart() {

    var scripts = document.getElementsByTagName("*");
    var lowCashElement = document.getElementById("cash_low");

    for (var i=0;i<scripts.length;i++) {
        if (scripts[i].innerText.toLowerCase().indexOf("$")>-1){
            var text = scripts[i].innerText.toLowerCase();
            //lowCashElement.innerText = "memes";
        }
    }

}

function home() {
	window.open("home.html", "_self");
}

function about() {
    window.open("about.html", "_self");
}

function signUp() {
	window.open("signup_mini.html", "_self");
}