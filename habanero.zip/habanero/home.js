document.addEventListener("DOMContentLoaded", function(event) {
    var signupButton = document.getElementById("signup");
    signupButton.onclick = signup;

    var statusButton = document.getElementById("curr");
    statusButton.onclick = status;

    var aboutButton = document.getElementById("about");
    aboutButton.onclick = about;
    
    var name = document.getElementById("firstname");
    name.innerText = localStorage.getItem("first");

    var open = document.getElementById("opener");

    /*var firstvisit = localStorage.getItem("firstvisit");
    if (firstvisit) {
        var cashGen = document.getElementById("cash_gen");
        cashGen.style.color = "#D85637";
        cashGen.innerText = "$___.__";
        var progTopGen = document.getElementById("progressTop");
        progTopGen.style.width = "160px";
        progTopGen.style.backgroundColor = "#D85637";
        open.innerText = "Sign up to begin."

        var foodGen = document.getElementById("cash_food");
        foodGen.style.color = "#D85637";
        foodGen.innerText = "$___.__";
        var progTopFood = document.getElementById("progressTop_food");
        progTopFood.style.width = "160px";
        progTopFood.style.backgroundColor = "#D85637";
        open.innerText = "Sign up to begin."

        var cashClothing = document.getElementById("cash_clothing");
        cashClothing.style.color = "#D85637";
        cashGen.innerText = "$___.__";
        var progTopClo = document.getElementById("progressTop_clothing");
        progTopClo.style.width = "160px";
        progTopClo.style.backgroundColor = "#D85637";
        open.innerText = "Sign up to begin."
    }*/

    getResults();
    showCart();
    showGeneral();
});

function getResults(){
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "checkForWord" }, function (response) {
            //showResults(response);
        });
        chrome.tabs.sendMessage(tabs[0].id, { action: "checkForCart" }, function (response) {
            //showCart();
        });
    });
}

/*function showResults(results) {
    var resultsElement = document.getElementById("results");
    var cashCart = document.getElementById("cashcart")
    resultsElement.innerText = (results.length > 0) ? "This is a checkout cart." : "This is NOT a checkout cart.";
}*/

function showGeneral() {
    var generalBal = localStorage.getItem("totalGeneralBudget");
    var foodBal = localStorage.getItem("totalFoodBudget");
    var clothingBal = localStorage.getItem("totalClothingBudget");
    var cashGeneralElement = document.getElementById("cash_gen");
    var cashFoodElement = document.getElementById("cash_food");
    var cashClothingElement = document.getElementById("cash_clothing");
    var progTopGeneralElement = document.getElementById("progressTop");
    var progTopFoodElement = document.getElementById("progressTop_food");
    var progTopClothingElement = document.getElementById("progressTop_clothing");
    var generalPercent = generalBal / 500;
    var foodPercent = foodBal / 500;
    var clothingPercent = clothingBal / 500;
    var opener = document.getElementById("opener");

    if (generalBal.length < 4) {
        generalBal = generalBal + ".00"

    }

    if (foodBal.length < 4) {
        foodBal = foodBal + ".00"
        
    }

    if (clothingBal.length < 4) {
        clothingBal = clothingBal + ".00"
        
    }

    progTopGeneralElement.style.width = (160 * generalPercent) + "px";
    progTopFoodElement.style.width = (160 * foodPercent) + "px";
    progTopClothingElement.style.width = (160 * clothingPercent) + "px";

    if (generalBal == ".00") {
        cashGeneralElement.style.color = "#D85637";
        cashGeneralElement.innerText = "$___.__";
        progTopGeneralElement.style.width = "160px";
        progTopGeneralElement.style.backgroundColor = "#D85637";
        opener.innerText = "Sign up to begin."
    }

    if (foodBal == ".00") {
        cashFoodElement.style.color = "#D85637";
        cashFoodElement.innerText = "$___.__";
        progTopFoodElement.style.width = "160px";
        progTopFoodElement.style.backgroundColor = "#D85637";
        opener.innerText = "Sign up to begin."
    }

    if (clothingBal == ".00") {
        cashClothingElement.style.color = "#D85637";
        cashClothingElement.innerText = "$___.__";
        progTopClothingElement.style.width = "160px";
        progTopClothingElement.style.backgroundColor = "#D85637";
        opener.innerText = "Sign up to begin."
    }

    else {
        cashGeneralElement.innerText = "$" + generalBal;
        cashFoodElement.innerText = "$" + foodBal;
        cashClothingElement.innerText = "$" + clothingBal;
    }
}

function showCart() {

    var scripts = document.getElementsByTagName("*");
    var lowCashElement = document.getElementById("cash_low");

    for (var i=0;i<scripts.length;i++) {
        if (scripts[i].innerText.toLowerCase().indexOf("$")>-1){
            var text = scripts[i].innerText.toLowerCase();
            //lowCashElement.innerText = "memes";
        }
    }

}

function status() {
	window.open("landing.html", "_self");
}

function about() {
    window.open("about.html", "_self");
}


function signup() {
	window.open("signup_mini.html", "_self");
}
